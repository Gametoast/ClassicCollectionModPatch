For use with the zero patch 2.0

Use this 'alternate_default' folder to install mod stuff into instead of overwriting your 
base game files.

Place in your addon/addon2 folder


-BAD_AL
